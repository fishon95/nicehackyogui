#pragma once
#include <Windows.h>
#include <vector>

#define USE_VMPROTECT false

namespace Globals
{

	namespace Modules
	{
		extern uintptr_t ShooterGame;
	}

}